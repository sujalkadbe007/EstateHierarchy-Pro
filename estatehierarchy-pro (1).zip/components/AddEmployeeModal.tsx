
import React, { useState, useEffect } from 'react';
import { Employee } from '../types';

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (name: string, role: string, parentId: string) => void;
  employees: Record<string, Employee>;
  initialParentId: string | null;
}

const AddEmployeeModal: React.FC<AddEmployeeModalProps> = ({ isOpen, onClose, onAdd, employees, initialParentId }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [parentId, setParentId] = useState(initialParentId || '');

  useEffect(() => {
    if (initialParentId) setParentId(initialParentId);
  }, [initialParentId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && role && parentId) {
      onAdd(name, role, parentId);
      setName('');
      setRole('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-800">New Team Member</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Full Name</label>
            <input 
              type="text" 
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
              placeholder="e.g. Jane Doe"
            />
          </div>
          
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Position / Role</label>
            <input 
              type="text" 
              required
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
              placeholder="e.g. Sales Associate"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Direct Supervisor</label>
            <select 
              value={parentId}
              onChange={(e) => setParentId(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all appearance-none"
            >
              {/* Fix: Explicitly cast Object.values to Employee[] to ensure correct property access */}
              {(Object.values(employees) as Employee[])
                .filter(e => e.level < 6)
                .sort((a,b) => a.level - b.level)
                .map(emp => (
                  <option key={emp.id} value={emp.id}>
                    Stage {emp.level}: {emp.name} ({emp.role})
                  </option>
                ))
              }
            </select>
          </div>

          <div className="pt-4">
            <button 
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/30 transition-all active:scale-95"
            >
              Add to Organization
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEmployeeModal;
