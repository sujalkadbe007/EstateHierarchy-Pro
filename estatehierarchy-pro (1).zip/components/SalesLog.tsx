
import React from 'react';
import { SaleRecord, Employee } from '../types';

interface SalesLogProps {
  sales: SaleRecord[];
  employees: Record<string, Employee>;
}

const SalesLog: React.FC<SalesLogProps> = ({ sales, employees }) => {
  if (sales.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 bg-white border border-slate-200 rounded-2xl shadow-sm text-slate-400">
        <svg className="w-12 h-12 mb-4 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
        <p className="text-lg font-medium">No sales recorded yet</p>
        <p className="text-sm">New transactions will appear here.</p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
      <table className="w-full text-left">
        <thead>
          <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs font-bold uppercase tracking-wider">
            <th className="px-6 py-4">Plot / Transaction</th>
            <th className="px-6 py-4">Sold By</th>
            <th className="px-6 py-4 text-right">Amount</th>
            <th className="px-6 py-4">Commission Distribution</th>
            <th className="px-6 py-4">Date</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 text-sm">
          {sales.map((sale) => {
            const seller = employees[sale.sellerId];
            return (
              <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <p className="font-bold text-slate-900">{sale.plotName}</p>
                  <p className="text-xs text-slate-400 font-mono">{sale.id}</p>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-400 text-xs">
                      {seller?.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-800">{seller?.name}</p>
                      <p className="text-[10px] text-slate-500 uppercase tracking-tight">Stage {seller?.level}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <p className="font-bold text-slate-900">₹{sale.amount.toLocaleString('en-IN')}</p>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-2">
                    {sale.commissionBreakdown.map((part, i) => (
                      <span key={i} className="px-2 py-1 bg-indigo-50 text-indigo-600 rounded text-[10px] font-bold">
                        {part.employeeName}: ₹{part.amount.toLocaleString('en-IN')} ({part.percentage}%)
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4 text-slate-500 whitespace-nowrap">
                  {new Date(sale.date).toLocaleDateString()}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default SalesLog;
