
import React, { useState } from 'react';
import { Employee } from '../types';
import { LEVEL_COLORS } from '../constants';

interface HierarchyViewProps {
  employees: Record<string, Employee>;
  onAddMember: (parentId: string) => void;
}

const EmployeeNode: React.FC<{ 
  empId: string; 
  employees: Record<string, Employee>; 
  onAdd: (id: string) => void 
}> = ({ empId, employees, onAdd }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const emp = employees[empId];
  if (!emp) return null;

  const colorClass = LEVEL_COLORS[emp.level] || 'bg-slate-500';

  return (
    <div className="relative">
      <div className="flex items-start gap-4">
        {/* Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 w-64 shadow-sm hover:shadow-md transition-shadow group relative overflow-hidden">
          <div className={`absolute top-0 left-0 w-full h-1 ${colorClass}`}></div>
          <div className="flex justify-between items-start mb-2">
            <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${colorClass} text-white`}>
              Stage {emp.level}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">{emp.id.slice(-4)}</span>
          </div>
          <h4 className="font-bold text-slate-900 truncate">{emp.name}</h4>
          <p className="text-xs text-slate-500 mb-3">{emp.role}</p>
          
          <div className="grid grid-cols-2 gap-2 text-[10px] border-t border-slate-100 pt-3">
            <div>
              <p className="text-slate-400 uppercase font-semibold">Earnings</p>
              <p className="font-bold text-emerald-600">₹{emp.commissionsEarned.toLocaleString('en-IN')}</p>
            </div>
            <div>
              <p className="text-slate-400 uppercase font-semibold">Reports</p>
              <p className="font-bold text-slate-700">{emp.childrenIds.length}</p>
            </div>
          </div>

          <div className="mt-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            {emp.level < 6 && (
              <button 
                onClick={() => onAdd(emp.id)}
                className="flex-1 bg-indigo-50 text-indigo-600 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors"
              >
                Add Member
              </button>
            )}
            {emp.childrenIds.length > 0 && (
              <button 
                onClick={() => setIsExpanded(!isExpanded)}
                className="px-2 bg-slate-50 text-slate-600 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-100"
              >
                {isExpanded ? 'Hide' : 'Show'}
              </button>
            )}
          </div>
        </div>

        {/* Children */}
        {isExpanded && emp.childrenIds.length > 0 && (
          <div className="ml-8 border-l-2 border-slate-100 pl-8 space-y-6 pt-4 relative">
             <div className="absolute top-0 left-0 w-8 h-0.5 bg-slate-100 -translate-y-2"></div>
            {emp.childrenIds.map(childId => (
              <EmployeeNode 
                key={childId} 
                empId={childId} 
                employees={employees} 
                onAdd={onAdd} 
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const HierarchyView: React.FC<HierarchyViewProps> = ({ employees, onAddMember }) => {
  const owner = (Object.values(employees) as Employee[]).find(e => e.level === 0);

  if (!owner) return <div>No organizational data found.</div>;

  return (
    <div className="min-w-max p-4">
      <EmployeeNode 
        empId={owner.id} 
        employees={employees} 
        onAdd={onAddMember} 
      />
    </div>
  );
};

export default HierarchyView;
