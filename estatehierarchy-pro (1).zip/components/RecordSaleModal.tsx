
import React, { useState } from 'react';
import { Employee } from '../types';

interface RecordSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRecord: (sellerId: string, amount: number, plotName: string) => void;
  employees: Record<string, Employee>;
}

const RecordSaleModal: React.FC<RecordSaleModalProps> = ({ isOpen, onClose, onRecord, employees }) => {
  const [sellerId, setSellerId] = useState('');
  const [amount, setAmount] = useState('');
  const [plotName, setPlotName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (sellerId && amount && plotName) {
      onRecord(sellerId, parseFloat(amount), plotName);
      setSellerId('');
      setAmount('');
      setPlotName('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-800">Record New Sale</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Plot Name / ID</label>
            <input 
              type="text" 
              required
              value={plotName}
              onChange={(e) => setPlotName(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
              placeholder="e.g. Garden View Plot #452"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Selling Price (₹)</label>
            <input 
              type="number" 
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
              placeholder="500000"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Closing Agent (Seller)</label>
            <select 
              value={sellerId}
              required
              onChange={(e) => setSellerId(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 appearance-none"
            >
              <option value="">Select an employee...</option>
              {(Object.values(employees) as Employee[])
                .sort((a,b) => a.name.localeCompare(b.name))
                .map(emp => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} (Stage {emp.level})
                  </option>
                ))
              }
            </select>
          </div>

          <div className="bg-emerald-50 p-4 rounded-xl text-emerald-800 text-xs leading-relaxed">
            <p className="font-bold mb-1">Commission Breakdown Rules:</p>
            <ul className="list-disc list-inside space-y-0.5 opacity-90">
              <li>Closing Agent: 5%</li>
              <li>Direct Supervisor: 2%</li>
              <li>Owner: 2-5% (scales up past Stage 6)</li>
            </ul>
          </div>

          <div className="pt-4">
            <button 
              type="submit"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-emerald-500/30 transition-all active:scale-95"
            >
              Confirm Transaction
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RecordSaleModal;
